import psycopg2

def connect_db():
    return psycopg2.connect(
        host="localhost",
        database="studentdb",
        user="postgres",
        password="admin123"
    )

def create_table(conn):
    cur = conn.cursor()
    table_name = input("Enter table name: ")
    columns = input("Enter columns (e.g. id SERIAL PRIMARY KEY, name VARCHAR(50), age INT, department VARCHAR(50)): ")
    cur.execute(f"CREATE TABLE IF NOT EXISTS {table_name} ({columns});")
    conn.commit()
    print(f"table '{table_name}' created")
    cur.close()

def insert_student(conn):
    cur = conn.cursor()
    while True:
        name = input("Enter student name (or 'q' to quit): ")
        if name.lower() == 'q':
            break
        age = int(input("Enter age: "))
        department = input("Enter department: ")
        cur.execute("INSERT INTO students (name, age, department) VALUES (%s, %s, %s);",
                    (name, age, department))
        conn.commit()
    cur.close()

def update_student(conn):
    cur = conn.cursor()
    name = input("Enter student name to update: ")
    new_dept = input("Enter new department: ")
    cur.execute("UPDATE students SET department=%s WHERE name=%s;", (new_dept, name))
    conn.commit()
    print("department updated")
    cur.close()

def delete_student(conn):
    cur = conn.cursor()
    student_id = int(input("Enter student ID to delete: "))
    cur.execute("DELETE FROM students WHERE id=%s;", (student_id,))
    conn.commit()
    print("student deleted")
    cur.close()

def query_data(conn):
    cur = conn.cursor()
    print("\n1. show all students\n2. filter by department\n3. average age by department\n4. names starting with letter")
    choice = input("Enter choice: ")

    if choice == '1':
        cur.execute("SELECT * FROM students;")
    elif choice == '2':
        dept = input("Enter department: ")
        cur.execute("SELECT * FROM students WHERE department=%s;", (dept,))
    elif choice == '3':
        cur.execute("SELECT department, AVG(age) FROM students GROUP BY department;")
    elif choice == '4':
        letter = input("Enter starting letter: ")
        cur.execute("SELECT * FROM students WHERE name ILIKE %s;", (letter + '%',))
    else:
        print("invalid choice")
        cur.close()
        return

    rows = cur.fetchall()
    for row in rows:
        print(row)

    cur.close()

def main():
    try:
        conn = connect_db()
        print("connected to db")

        while True:
            print("""
1. create table
2. insert student
3. update student
4. delete student
5. query data
6. exit
""")
            choice = input("enter your choice: ")
            if choice == '1':
                create_table(conn)
            elif choice == '2':
                insert_student(conn)
            elif choice == '3':
                update_student(conn)
            elif choice == '4':
                delete_student(conn)
            elif choice == '5':
                query_data(conn)
            elif choice == '6':
                print("exiting")
                break
            else:
                print("invalid choice")

    except Exception as e:
        print("Error:", e)
    finally:
        if conn:
            conn.close()
            print("connection closed")

if __name__ == "__main__":
    main()
