# PostgreSQL Lab (Docker + Python)

## Setup Instructions

1. Ensure Docker is installed and running.
2. Pull and run PostgreSQL container:
   ```bash
   docker run --name pg_lab -e POSTGRES_PASSWORD=admin123 -p 5432:5432 -d postgres

3. docker exec -it pg_lab psql -U postgres -c "CREATE DATABASE studentdb;"

4. python -m venv venv
   venv\Scripts\activate
   pip install -r requirements.txt

5. run "python main.py"




